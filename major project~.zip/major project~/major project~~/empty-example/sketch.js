let video,img;
let poseNet;
let noseX=0 , noseY=0;

function setup() {
  createCanvas(640, 480);
  img = loadImage('images/aero.png');
  video =  createCapture(VIDEO);
  video.hide();

poseNet  = ml5.poseNet(video , modelReady);
poseNet.on('pose' , gotPosses);
  //console.log(ml5);
}

function gotPosses(poses){
//console.log(poses);
if(poses.length>0){
let newX = poses[0].pose.keypoints[0].position.x;
let newY = poses[0].pose.keypoints[0].position.y;

//using lerp function to smoothing the motion of the ball
noseX = lerp(noseX , newX , 0.5);
noseY = lerp(noseY ,newY , 0.5);
}
}

function modelReady(){
//  console.log('model ready');
}


function draw() {
//  background(220);
image(video,0,0);
fill(255,0,0);
//ellipse(noseX,noseY,50);

filter(THRESHOLD);

image(img ,noseX - 50,noseY-50 ,100,100);
}
