
var Bricks;
function setup() {
  createCanvas(640, 480);

// creating bricks object
  Bricks= new bricks();


}



function draw() {
background(220);

  Bricks.fall();
  Bricks.show();


}
