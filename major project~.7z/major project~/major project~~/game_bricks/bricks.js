var y=[];
var x;
function bricks(){
x=0;
y[1] = 0;
y[2]=-240;
y[3]=-480;
y[4]=-720;



this.Yspeed =2;

this.fall = function(){
for(var i=0;i<y.length;i++){
  y[i] = y[i] + this.Yspeed;
}

//for bricks crossing the bottom limits
for(var i =0 ;i<y.length;i++){
  if(y[i]>height){
    y[i] = -4*(height/2);
  }
}
}

this.show = function(){

rect(x ,y[1] , 450 , 40 );
rect(x , y[2] , 450 , 40 );
rect(x , y[3] , 450 , 40 );
rect(x , y[4] , 450 , 40 );

}



}
